<?php

namespace App\Core\Exceptions;

use Exception;

class RouteNotFoundException extends Exception
{
}