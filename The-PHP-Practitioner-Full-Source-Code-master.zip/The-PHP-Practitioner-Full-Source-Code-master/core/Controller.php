<?php

namespace App\Core;

abstract class Controller
{
}
